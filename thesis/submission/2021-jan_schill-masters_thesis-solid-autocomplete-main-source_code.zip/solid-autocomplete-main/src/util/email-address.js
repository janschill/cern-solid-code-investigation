export function stripMailtoTag (emailAddress) {
  return emailAddress.replace('mailto:', '')
}
