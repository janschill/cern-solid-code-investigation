export default class Session {
  constructor (params) {
    this.session = params.session
    this.agent = params.agent
  }
}
