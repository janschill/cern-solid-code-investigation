export default {
  comments: {
    state: 'idle',
    data: []
  },
  commentInput: {
    state: 'idle',
    data: ''
  },
  errorMessage: {
    state: 'idle',
    data: ''
  },
  session: {
    state: 'idle',
    data: {}
  },
  solidClient: {
    state: 'idle',
    data: {}
  }
}
